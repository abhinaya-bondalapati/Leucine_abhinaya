#RECRUITMENT PORTAL (SIGNIN AND LOGINFORM)
Tools used:
   Front end: React(JavaScript),CSS.
   Back End:Node.js, Postman Database.
This the portal where the user is new to the website he/she has to signin with the details, after signin the user can  redirect to the login page,then it displays the sometexx with your 
username.In this portal we have connected database through postman.
